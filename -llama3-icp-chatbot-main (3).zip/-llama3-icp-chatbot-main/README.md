# -llama3-icp-chatbot
A simple Motoko canister that uses Llama 3 LLM to handle prompt and chat interactions on the Internet Computer.
